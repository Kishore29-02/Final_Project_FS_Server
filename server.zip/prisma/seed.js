import { PrismaClient, Role, Status, RetentionStatus } from '@prisma/client';
import { faker } from '@faker-js/faker';

const prisma = new PrismaClient();

async function main() {
  // Create some employees
  for (let i = 0; i < 10; i++) {
    const firstName = faker.person.firstName();
    const lastName = faker.person.lastName();
    const department = faker.commerce.department();
    const designation = faker.person.jobTitle();
    const dateHired = faker.date.past();
    const status = i % 2 === 0 ? Status.ACTIVE : Status.TERMINATED;

    // Create Employee
    const employee = await prisma.employee.create({
      data: {
        first_name: firstName,
        last_name: lastName,
        department,
        designation,
        date_hired: dateHired,
        status,
        users: {
          create: [
            {
              email: faker.internet.email(firstName, lastName),
              password: faker.internet.password(),
              role: i % 2 === 0 ? Role.USER : Role.ADMIN,
            },
          ],
        },
      },
    });

    // Create courses for designation
    const courseForDesignation = await prisma.courseForDesignation.create({
      data: {
        designation,
        courses: {
          create: [
            {
              course_name: faker.company.name(),
              description: faker.lorem.sentence(),
              duration: faker.number.int({ min: 10, max: 40 }),
            },
          ],
        },
      },
    });

    console.log(courseForDesignation);

    // Create Course Performance
    await prisma.coursePerformance.create({
      data: {
        employeeId: employee.id,
        courseId: courseForDesignation.courses[0].id,
        score: faker.number.float({ min: 50, max: 100, precision: 0.01 }),
        completionDate: faker.date.past(),
      },
    });

    // Create Project Performance
    await prisma.projectPerformance.create({
      data: {
        employeeId: employee.id,
        projectName: faker.commerce.productName(),
        performanceScore: faker.number.float({ min: 1, max: 5, precision: 0.1 }),
        feedback: faker.lorem.sentence(),
        evaluationDate: faker.date.recent(),
      },
    });

    // Create Retention Data
    await prisma.retention.create({
      data: {
        employeeId: employee.id,
        retentionDate: faker.date.past(),
        retentionStatus: i % 2 === 0 ? RetentionStatus.RETAINED : RetentionStatus.TERMINATED,
        terminationReason: i % 2 === 0 ? null : faker.lorem.sentence(),
      },
    });
  }
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
