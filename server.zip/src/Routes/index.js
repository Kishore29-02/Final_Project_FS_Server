const express = require('express');
const loginRouter = require('./login');

const router = express.Router();

router.use("/login",loginRouter);
router.use("/register",require('./register'));

// router.use("/survey",require('./Surveys'));

module.exports = router;