const {PrismaClient} = require('@prisma/client');
const prisma = new PrismaClient();

async function verifyEmail(email) {
    const res = await prisma.user.findFirst({
        where: {
            email: email,
        }
    });
    
    return res;
}

module.exports = {
    verifyEmail,
}
